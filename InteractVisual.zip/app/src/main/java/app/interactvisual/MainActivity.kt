package app.interactvisual

import android.Manifest
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = ScriptStore(applicationContext)
        setContent { App(store) }
    }
}

sealed interface Screen {
    data object Home : Screen
    data object Docs : Screen
    data class Edit(val name: String, val code: String) : Screen
    data class Run(val title: String, val code: String) : Screen
}

private val TRIMS = intArrayOf(-30, 0, 30, 60, 90)

tailrec fun Context.activity(): ComponentActivity = when (this) {
    is ComponentActivity -> this
    is ContextWrapper -> baseContext.activity()
    else -> error("tidak ada activity")
}

const val TEMPLATE = """# skrip baru - frame() dipanggil tiap frame (30-60x per detik)
# ctx.hands = daftar tangan, ctx.w / ctx.h = ukuran layar (px), ctx.dp = skala layar

def frame(ctx, d):
    for hand in ctx.hands:
        x, y, z = hand.tip(1)  # ujung telunjuk (px)
        d.circle(x, y, 18 * ctx.dp, "#FF1A1F", 3 * ctx.dp)
        d.text(x + 24 * ctx.dp, y, "halo", "#FFFFFF", 16 * ctx.dp)
"""

@Composable
fun App(store: ScriptStore) {
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    val scheme = darkColorScheme(
        primary = C.red,
        background = C.bg,
        surface = C.panel,
        onBackground = C.text,
        onSurface = C.text,
    )
    MaterialTheme(colorScheme = scheme) {
        Box(Modifier.fillMaxSize().background(C.bg)) {
            BackHandler(enabled = screen !is Screen.Home) { screen = Screen.Home }
            when (val s = screen) {
                is Screen.Home -> HomeScreen(store) { screen = it }
                is Screen.Docs -> DocsScreen { screen = Screen.Home }
                is Screen.Edit -> EditScreen(store, s.name, s.code) { screen = it }
                is Screen.Run -> RunScreen(s.title, s.code) { screen = Screen.Home }
            }
        }
    }
}

@Composable
fun HomeScreen(store: ScriptStore, nav: (Screen) -> Unit) {
    val ctx = LocalContext.current
    var mine by remember { mutableStateOf(store.list()) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val n = store.import(uri)
            mine = store.list()
            Toast.makeText(ctx, if (n != null) "diimpor: $n.py" else "gagal membaca file", Toast.LENGTH_SHORT).show()
        }
    }
    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                painterResource(R.drawable.logo),
                contentDescription = null,
                modifier = Modifier.size(52.dp).clip(RoundedCornerShape(10.dp)),
            )
            Spacer(Modifier.width(14.dp))
            Column {
                Txt("interact visual", size = 20, bold = true)
                Txt("python di atas kamera", C.dim, 12)
            }
        }
        Spacer(Modifier.height(26.dp))
        Txt("preset", C.dim, 12)
        Spacer(Modifier.height(8.dp))
        store.presets.forEach { p ->
            Card {
                Txt(p.title, size = 16, bold = true)
                Spacer(Modifier.height(4.dp))
                Txt(p.desc, C.dim, 12)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Btn("jalankan", { nav(Screen.Run(p.title, store.presetCode(p.id))) }, primary = true)
                    Btn("salin & edit", { nav(Screen.Edit(store.uniqueName(p.id), store.presetCode(p.id))) })
                }
            }
            Spacer(Modifier.height(10.dp))
        }

        Spacer(Modifier.height(18.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Txt("skrip kamu", C.dim, 12, modifier = Modifier.weight(1f))
            Btn("baru", { nav(Screen.Edit(store.uniqueName("skrip_baru"), TEMPLATE)) })
            Btn("unggah .py", { picker.launch(arrayOf("*/*")) })
        }
        Spacer(Modifier.height(8.dp))
        if (mine.isEmpty()) {
            Txt("Belum ada skrip. Tulis baru atau unggah file .py dari ponsel.", C.dim, 12)
        }
        mine.forEach { n ->
            Card {
                Txt("$n.py", size = 14, bold = true)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Btn("jalankan", { nav(Screen.Run(n, store.read(n))) }, primary = true)
                    Btn("edit", { nav(Screen.Edit(n, store.read(n))) })
                    Btn("hapus", {
                        store.delete(n)
                        mine = store.list()
                    })
                }
            }
            Spacer(Modifier.height(10.dp))
        }
        Spacer(Modifier.height(18.dp))
        Btn("referensi API", { nav(Screen.Docs) })
    }
}

@Composable
fun DocsScreen(back: () -> Unit) {
    val ctx = LocalContext.current
    val text = remember { ctx.assets.open("docs.txt").bufferedReader().use { it.readText() } }
    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Btn("‹", back)
            Spacer(Modifier.width(12.dp))
            Txt("referensi API", size = 16, bold = true)
        }
        Box(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            Txt(text, C.text, 12)
        }
    }
}

// ---------- editor ----------

private val KW = Regex("\\b(def|class|return|if|elif|else|for|while|in|not|and|or|is|import|from|as|with|try|except|finally|raise|pass|break|continue|lambda|global|nonlocal|None|True|False|yield)\\b")
private val NUM = Regex("\\b\\d+(\\.\\d+)?\\b")
private val STR = Regex("(\"[^\"\\n]*\"|'[^'\\n]*')")
private val COM = Regex("#[^\\n]*")

object PyHighlight : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val s = text.text
        val b = AnnotatedString.Builder(s)
        fun mark(r: Regex, c: Color) {
            r.findAll(s).forEach { b.addStyle(SpanStyle(color = c), it.range.first, it.range.last + 1) }
        }
        mark(NUM, C.cyan)
        mark(KW, C.red)
        mark(STR, C.amber)
        mark(COM, C.dim)
        return TransformedText(b.toAnnotatedString(), OffsetMapping.Identity)
    }
}

@Composable
fun EditScreen(store: ScriptStore, name0: String, code0: String, nav: (Screen) -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf(name0) }
    var code by remember { mutableStateOf(code0) }
    val style = TextStyle(color = C.text, fontFamily = Mono, fontSize = 13.sp, lineHeight = 20.sp)
    val lines = code.count { it == '\n' } + 1

    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Btn("‹", { nav(Screen.Home) })
            BasicTextField(
                value = name,
                onValueChange = { v -> name = v.filter { it.isLetterOrDigit() || it == '_' || it == '-' } },
                singleLine = true,
                textStyle = TextStyle(color = C.red, fontFamily = Mono, fontSize = 15.sp, fontWeight = FontWeight.Bold),
                cursorBrush = SolidColor(C.red),
                modifier = Modifier.weight(1f),
            )
            Txt(".py", C.dim, 13)
            Btn("simpan", {
                store.write(name, code)
                Toast.makeText(ctx, "tersimpan: $name.py", Toast.LENGTH_SHORT).show()
            })
            Btn("jalankan", {
                store.write(name, code)
                nav(Screen.Run(name, code))
            }, primary = true)
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(C.line))
        Row(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Text(
                text = (1..lines).joinToString("\n"),
                style = style.copy(color = C.dim, textAlign = TextAlign.End),
                modifier = Modifier.width(44.dp).padding(top = 10.dp, end = 8.dp),
            )
            Box(Modifier.weight(1f).horizontalScroll(rememberScrollState()).padding(top = 10.dp, bottom = 240.dp)) {
                BasicTextField(
                    value = code,
                    onValueChange = { code = it },
                    textStyle = style,
                    cursorBrush = SolidColor(C.red),
                    visualTransformation = PyHighlight,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
                    modifier = Modifier.defaultMinSize(minWidth = 500.dp, minHeight = 400.dp),
                )
            }
        }
    }
}

// ---------- runner ----------

@Composable
fun RunScreen(title: String, code: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val act = remember { ctx.activity() }
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val req = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) req.launch(Manifest.permission.CAMERA) }

    var front by remember { mutableStateOf(false) }
    var showLog by remember { mutableStateOf(false) }
    var log by remember { mutableStateOf("") }
    var runId by remember { mutableIntStateOf(0) }
    var fps by remember { mutableIntStateOf(0) }
    var det by remember { mutableIntStateOf(0) }
    var lag by remember { mutableIntStateOf(0) }
    var trimIdx by remember { mutableIntStateOf(1) }

    val tracker = remember { Tracker(ctx.applicationContext) }
    var inf by remember { mutableIntStateOf(0) }
    var gpuOn by remember { mutableStateOf(tracker.gpu) }
    var handsN by remember { mutableIntStateOf(tracker.numHands) }
    var opsi by remember { mutableStateOf(false) }
    val overlay = remember { OverlayView(ctx) }
    val preview = remember {
        PreviewView(ctx).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.PERFORMANCE
        }
    }
    val engine = remember { PyEngine(tracker, overlay) }

    // layar penuh + tetap menyala
    DisposableEffect(Unit) {
        val w = act.window
        val c = WindowCompat.getInsetsController(w, w.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
        w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            w.attributes = w.attributes.also {
                it.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        onDispose {
            c.show(WindowInsetsCompat.Type.systemBars())
            w.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            if (Build.VERSION.SDK_INT >= 28) {
                w.attributes = w.attributes.also {
                    it.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
                }
            }
        }
    }

    DisposableEffect(Unit) {
        tracker.onError = { m ->
            log = (log + "[sistem] " + m + "\n").takeLast(4000)
            showLog = true
        }
        tracker.open()
        onDispose { tracker.close() }
    }

    LaunchedEffect(granted, front) {
        if (granted) tracker.bind(act, preview, front)
    }

    DisposableEffect(code, runId) {
        val density = ctx.resources.displayMetrics.density
        engine.start(
            code, title, density,
            onLog = { t ->
                log = (log + t).takeLast(4000)
                if (t.contains("Error") || t.contains("Traceback")) showLog = true
            },
            onFps = { f ->
                fps = f
                det = tracker.detFps
                lag = tracker.lagMs
                inf = tracker.inferMs
                gpuOn = tracker.gpu
                handsN = tracker.numHands
            },
        )
        onDispose { engine.stop() }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView({ preview }, Modifier.fillMaxSize())
        AndroidView({ overlay }, Modifier.fillMaxSize())

        Column(Modifier.fillMaxWidth().displayCutoutPadding().padding(start = 24.dp, end = 24.dp, top = 24.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Btn("×", onClose, glass = true)
                Column(Modifier.weight(1f)) {
                    Txt(title, Color.White, 13, true)
                    Txt("$fps fps  deteksi $det/s", Color(0xCCFFFFFF), 11)
                    Txt("infer ${inf}ms  lag ${lag}ms  " + (if (gpuOn) "gpu" else "cpu") + " $handsN tangan", Color(0xCCFFFFFF), 11)
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Btn(if (front) "depan" else "belakang", { front = !front }, glass = true)
                Btn("log", { showLog = !showLog }, glass = true)
                Btn("ulang", { runId += 1 }, glass = true)
                Btn(if (opsi) "opsi -" else "opsi +", { opsi = !opsi }, glass = true)
            }
            if (opsi) {
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val t = TRIMS[trimIdx]
                    Btn("prediksi " + (if (t > 0) "+" else "") + t, {
                        trimIdx = (trimIdx + 1) % TRIMS.size
                        tracker.trimMs = TRIMS[trimIdx]
                    }, glass = true)
                    Btn(if (gpuOn) "pakai cpu" else "pakai gpu", {
                        tracker.setGpu(!tracker.gpu)
                        gpuOn = tracker.gpu
                    }, glass = true)
                    Btn(if (handsN == 1) "tangan 2" else "tangan 1", {
                        tracker.setHands(if (tracker.numHands == 1) 2 else 1)
                        handsN = tracker.numHands
                    }, glass = true)
                }
            }
        }

        if (!granted) {
            Column(
                Modifier.align(Alignment.Center).padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Txt("Izin kamera dibutuhkan untuk menjalankan skrip.", Color.White, 13)
                Btn("beri izin", { req.launch(Manifest.permission.CAMERA) }, primary = true)
            }
        }

        if (showLog) {
            val sc = rememberScrollState()
            LaunchedEffect(log) { sc.scrollTo(sc.maxValue) }
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .fillMaxHeight(0.4f)
                    .background(Color(0xE6000000))
                    .padding(12.dp),
            ) {
                Column(Modifier.verticalScroll(sc)) {
                    Txt(
                        if (log.isEmpty()) "(log kosong - print() muncul di sini)" else log,
                        if (log.contains("Traceback") || log.contains("Error")) Color(0xFFFF6B6B) else C.text,
                        11,
                    )
                }
            }
        }
    }
}
