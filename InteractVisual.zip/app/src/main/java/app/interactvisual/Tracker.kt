package app.interactvisual

import android.content.Context
import android.graphics.Bitmap
import android.hardware.display.DisplayManager
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.util.Size
import android.view.Display
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.ImageProcessingOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.hypot

/** Tangan yang siap dikirim ke Python: tiap tangan = 21 titik (x,y,z) ternormalisasi, sudah di-mirror untuk kamera depan. */
class HandsFrame(val hands: List<FloatArray>, val imgW: Int, val imgH: Int)

/** Hasil deteksi terakhir + kecepatan tiap koordinat (per detik) untuk prediksi antar-deteksi. */
class Snap(val pos: List<FloatArray>, val vel: List<FloatArray>, val capNs: Long, val imgW: Int, val imgH: Int)

/** One-Euro filter: halus saat diam, responsif saat gerak cepat. */
class OneEuro(private val minCut: Float, private val beta: Float, private val dCut: Float = 1f) {
    private var xPrev = 0f
    private var dxPrev = 0f
    private var has = false

    private fun alpha(cut: Float, dt: Float): Float {
        val tau = 1f / (2f * PI.toFloat() * cut)
        return 1f / (1f + tau / dt)
    }

    fun filter(x: Float, dt: Float): Float {
        if (!has) {
            has = true
            xPrev = x
            dxPrev = 0f
            return x
        }
        val dx = (x - xPrev) / dt
        val ad = alpha(dCut, dt)
        val dxHat = ad * dx + (1f - ad) * dxPrev
        val a = alpha(minCut + beta * abs(dxHat), dt)
        val xHat = a * x + (1f - a) * xPrev
        xPrev = xHat
        dxPrev = dxHat
        return xHat
    }
}

/** Satu koordinat: posisi (One-Euro) + kecepatan (low-pass) dari posisi yang sudah halus. */
class Track {
    private val f = OneEuro(2f, 30f)
    private var prev = 0f
    private var has = false
    var vel = 0f
        private set

    fun update(x: Float, dt: Float): Float {
        val xh = f.filter(x, dt)
        if (has) vel += 0.7f * ((xh - prev) / dt - vel)
        prev = xh
        has = true
        return xh
    }
}

class HandSmoother {
    private var bank = Array(2) { newBank() }
    private val lastX = FloatArray(2) { -1f }
    private var lastCap = 0.0

    private fun newBank() = Array(63) { Track() }

    fun reset() {
        bank = Array(2) { newBank() }
        lastX.fill(-1f)
        lastCap = 0.0
    }

    /** dt dihitung dari waktu tangkap kamera (bukan waktu hasil tiba), jadi tidak ikut goyang karena inferensi. */
    fun apply(raw: List<FloatArray>, capSec: Double): Pair<List<FloatArray>, List<FloatArray>> {
        val dt = (capSec - lastCap).toFloat().coerceIn(0.008f, 0.2f)
        lastCap = capSec
        val pos = ArrayList<FloatArray>(2)
        val vel = ArrayList<FloatArray>(2)
        raw.take(2).forEachIndexed { s, a ->
            if (lastX[s] >= 0f && abs(a[0] - lastX[s]) > 0.3f) bank[s] = newBank()
            lastX[s] = a[0]
            val p = FloatArray(63)
            val v = FloatArray(63)
            for (i in 0 until 63) {
                p[i] = bank[s][i].update(a[i], dt)
                v[i] = bank[s][i].vel
            }
            pos.add(p)
            vel.add(v)
        }
        for (s in pos.size until 2) lastX[s] = -1f
        return Pair(pos, vel)
    }
}

/** CameraX + MediaPipe HandLandmarker. Ambil posisi tangan per-vsync lewat [sample]. */
class Tracker(private val app: Context) {
    @Volatile var front = false
    /** Tambahan (ms) pada prediksi ke depan. Positif = overlay lebih "maju". */
    @Volatile var trimMs = 0
    @Volatile var detFps = 0
    @Volatile var lagMs = 0
    var onError: (String) -> Unit = {}

    @Volatile private var snap: Snap? = null
    @Volatile private var landmarker: HandLandmarker? = null
    private var analysis: ImageAnalysis? = null
    private val exec = Executors.newSingleThreadExecutor { r ->
        Thread({
            Process.setThreadPriority(Process.THREAD_PRIORITY_DISPLAY)
            r.run()
        }, "iv-analysis")
    }
    private val smoother = HandSmoother()
    private val caps = ConcurrentHashMap<Long, Long>()
    private var reuse: Bitmap? = null
    @Volatile private var upW = 480
    @Volatile private var upH = 640
    private var lastTs = 0L
    private var lastSeen = 0.0
    private var detCount = 0
    private var detT = 0L

    private val dm = app.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
    private val dl = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {
            analysis?.targetRotation = displayRotation()
        }
    }

    private fun displayRotation(): Int = dm.getDisplay(Display.DEFAULT_DISPLAY)?.rotation ?: 0

    fun open() {
        dm.registerDisplayListener(dl, Handler(Looper.getMainLooper()))
        Thread {
            try {
                val base = BaseOptions.builder().setModelAssetPath("hand_landmarker.task").build()
                val opts = HandLandmarker.HandLandmarkerOptions.builder()
                    .setBaseOptions(base)
                    .setRunningMode(RunningMode.LIVE_STREAM)
                    .setNumHands(2)
                    .setMinHandDetectionConfidence(0.5f)
                    .setMinHandPresenceConfidence(0.5f)
                    .setMinTrackingConfidence(0.5f)
                    .setResultListener { r, _ -> onResult(r) }
                    .setErrorListener { e -> onError("mediapipe: ${e.message}") }
                    .build()
                landmarker = HandLandmarker.createFromOptions(app, opts)
            } catch (e: Exception) {
                onError("model hand_landmarker.task gagal dimuat: ${e.message}\n(file harus ada di app/src/main/assets, build GitHub mengunduhnya otomatis)")
            }
        }.start()
    }

    /** Bitmap dipakai ulang (tanpa alokasi 1 MB per frame); MediaPipe menyalin pikselnya saat detectAsync dipanggil. */
    private fun frameBitmap(p: ImageProxy): Bitmap {
        val plane = p.planes[0]
        if (plane.pixelStride != 4 || plane.rowStride != p.width * 4) return p.toBitmap()
        var b = reuse
        if (b == null || b.width != p.width || b.height != p.height) {
            b = Bitmap.createBitmap(p.width, p.height, Bitmap.Config.ARGB_8888)
            reuse = b
        }
        val buf = plane.buffer
        buf.rewind()
        b.copyPixelsFromBuffer(buf)
        return b
    }

    private val analyzer = ImageAnalysis.Analyzer { proxy ->
        val lm = landmarker
        try {
            if (lm != null) {
                val nowNs = SystemClock.elapsedRealtimeNanos()
                val tsNs = proxy.imageInfo.timestamp
                // waktu tangkap sensor kalau satu basis waktu dengan jam sistem, kalau tidak pakai waktu tiba
                val capNs = if (abs(nowNs - tsNs) < 2_000_000_000L) tsNs else nowNs
                val rot = proxy.imageInfo.rotationDegrees
                val swap = rot % 180 != 0
                upW = if (swap) proxy.height else proxy.width
                upH = if (swap) proxy.width else proxy.height
                val bitmap = frameBitmap(proxy)
                val opts = ImageProcessingOptions.builder().setRotationDegrees(rot).build()
                var ts = SystemClock.uptimeMillis()
                if (ts <= lastTs) ts = lastTs + 1
                lastTs = ts
                caps[ts] = capNs
                if (caps.size > 64) caps.clear()
                lm.detectAsync(BitmapImageBuilder(bitmap).build(), opts, ts)
            }
        } catch (e: Exception) {
            onError("analisis frame: ${e.message}")
        } finally {
            proxy.close()
        }
    }

    private fun onResult(r: HandLandmarkerResult) {
        val nowNs = SystemClock.elapsedRealtimeNanos()
        val capNs = caps.remove(r.timestampMs()) ?: nowNs
        val capSec = capNs / 1e9
        val fr = front

        detCount++
        if (nowNs - detT > 1_000_000_000L) {
            detFps = detCount
            detCount = 0
            detT = nowNs
        }
        lagMs = ((nowNs - capNs) / 1_000_000L).toInt()

        val raw = r.landmarks().map { lm ->
            val a = FloatArray(63)
            for (i in 0 until 21) {
                val p = lm[i]
                a[i * 3] = if (fr) 1f - p.x() else p.x()
                a[i * 3 + 1] = p.y()
                a[i * 3 + 2] = p.z()
            }
            a
        }.sortedBy { it[0] }

        if (raw.isEmpty()) {
            // tahan hasil terakhir 120 ms supaya tidak berkedip saat 1-2 frame gagal deteksi
            val cur = snap
            if (cur != null && cur.pos.isNotEmpty() && capSec - lastSeen > 0.12) {
                smoother.reset()
                snap = Snap(emptyList(), emptyList(), capNs, upW, upH)
            }
            return
        }
        lastSeen = capSec
        val (p, v) = smoother.apply(raw, capSec)
        snap = Snap(p, v, capNs, upW, upH)
    }

    /**
     * Posisi tangan untuk waktu tampil [dispNs] (jam elapsedRealtime).
     * Deteksi datang ~20-30x/detik dan telat dari kamera, jadi posisi diekstrapolasi dengan kecepatan
     * ke waktu tampil, dikurangi lag preview kamera sendiri. Dengan begitu overlay bergerak mulus tiap vsync.
     */
    fun sample(dispNs: Long): HandsFrame? {
        val s = snap ?: return null
        if (s.pos.isEmpty()) return HandsFrame(emptyList(), s.imgW, s.imgH)
        val h = ((dispNs - s.capNs) / 1e9f - PREVIEW_LAT + trimMs / 1000f).coerceIn(0f, 0.12f)
        val hands = List(s.pos.size) { i ->
            val p = s.pos[i]
            val v = s.vel[i]
            // gerbang kecepatan telapak (titik 9): saat diam prediksi mati, supaya noise tidak diperbesar
            val sp = hypot(v[27], v[28])
            val g = ((sp - 0.06f) / 0.14f).coerceIn(0f, 1f)
            val k = h * g * g * (3f - 2f * g)
            FloatArray(63) { j -> p[j] + v[j] * k }
        }
        return HandsFrame(hands, s.imgW, s.imgH)
    }

    fun bind(owner: LifecycleOwner, pv: PreviewView, useFront: Boolean) {
        front = useFront
        smoother.reset()
        snap = null
        val fut = ProcessCameraProvider.getInstance(app)
        fut.addListener({
            try {
                val provider = fut.get()
                val preview = Preview.Builder().build()
                preview.setSurfaceProvider(pv.surfaceProvider)
                val an = ImageAnalysis.Builder()
                    .setResolutionSelector(
                        ResolutionSelector.Builder()
                            .setResolutionStrategy(
                                ResolutionStrategy(
                                    Size(640, 480),
                                    ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER,
                                ),
                            )
                            .build(),
                    )
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .setTargetRotation(displayRotation())
                    .build()
                an.setAnalyzer(exec, analyzer)
                analysis = an
                provider.unbindAll()
                provider.bindToLifecycle(
                    owner,
                    if (useFront) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA,
                    preview,
                    an,
                )
            } catch (e: Exception) {
                onError("kamera: ${e.message}")
            }
        }, ContextCompat.getMainExecutor(app))
    }

    fun unbind() {
        try {
            ProcessCameraProvider.getInstance(app).get().unbindAll()
        } catch (e: Exception) {
            // belum siap, abaikan
        }
    }

    fun close() {
        dm.unregisterDisplayListener(dl)
        unbind()
        try {
            landmarker?.close()
        } catch (e: Exception) {
        }
        landmarker = null
        exec.shutdown()
    }

    companion object {
        /** Perkiraan lag tampil preview kamera itu sendiri (detik); sisanya yang dikompensasi prediksi. */
        const val PREVIEW_LAT = 0.06f
    }
}
