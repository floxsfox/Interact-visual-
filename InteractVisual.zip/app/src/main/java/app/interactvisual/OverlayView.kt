package app.interactvisual

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.view.View
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Menggambar buffer float biner dari Python tanpa alokasi per frame.
 * Format tiap perintah: [tipe, lebar, a, r, g, b, fill, n, payload(n)].
 * tipe: 1 garis/segmen, 2 lingkaran, 3 kotak, 4 poligon, 5 teks.
 */
class OverlayView(context: Context) : View(context) {

    private class Buf {
        var f = FloatArray(8192)
        var n = 0
    }

    private val bufs = arrayOf(Buf(), Buf(), Buf())
    private var wi = 0

    @Volatile
    private var shown: Buf? = null
    private var chars = CharArray(256)

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        typeface = Typeface.MONOSPACE
    }
    private val path = Path()
    private val density = resources.displayMetrics.density

    fun clear() {
        shown = null
        postInvalidate()
    }

    /** Dipanggil dari thread Python (satu thread). Triple buffer: UI selalu membaca buffer yang sudah selesai. */
    fun submit(bytes: ByteArray) {
        val cnt = bytes.size / 4
        wi = (wi + 1) % 3
        val b = bufs[wi]
        if (b.f.size < cnt) b.f = FloatArray(cnt + 2048)
        ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer().get(b.f, 0, cnt)
        b.n = cnt
        shown = b
        postInvalidateOnAnimation()
    }

    override fun onDraw(c: Canvas) {
        val b = shown
        if (b != null) {
            val f = b.f
            val total = b.n
            var i = 0
            while (i + 8 <= total) {
                val t = f[i].toInt()
                val w = f[i + 1]
                val cnt = f[i + 7].toInt()
                val p = i + 8
                if (cnt < 0 || p + cnt > total) break
                paint.color = Color.argb(f[i + 2].toInt(), f[i + 3].toInt(), f[i + 4].toInt(), f[i + 5].toInt())
                val fill = f[i + 6] > 0.5f
                when (t) {
                    1 -> {
                        paint.style = Paint.Style.STROKE
                        paint.strokeWidth = w
                        c.drawLines(f, p, (cnt / 4) * 4, paint)
                    }
                    2 -> {
                        paint.style = if (fill) Paint.Style.FILL else Paint.Style.STROKE
                        paint.strokeWidth = w
                        c.drawCircle(f[p], f[p + 1], f[p + 2], paint)
                    }
                    3 -> {
                        paint.style = if (fill) Paint.Style.FILL else Paint.Style.STROKE
                        paint.strokeWidth = w
                        c.drawRect(f[p], f[p + 1], f[p] + f[p + 2], f[p + 1] + f[p + 3], paint)
                    }
                    4 -> if (cnt >= 4) {
                        path.reset()
                        path.moveTo(f[p], f[p + 1])
                        var k = 2
                        while (k + 1 < cnt) {
                            path.lineTo(f[p + k], f[p + k + 1])
                            k += 2
                        }
                        path.close()
                        paint.style = if (fill) Paint.Style.FILL else Paint.Style.STROKE
                        paint.strokeWidth = w
                        c.drawPath(path, paint)
                    }
                    5 -> if (cnt >= 3) {
                        val len = cnt - 3
                        if (chars.size < len) chars = CharArray(len + 64)
                        for (k in 0 until len) chars[k] = f[p + 3 + k].toInt().toChar()
                        paint.style = Paint.Style.FILL
                        paint.textSize = f[p + 2]
                        c.drawText(chars, 0, len, f[p], f[p + 1], paint)
                    }
                }
                i = p + cnt
            }
        }
        brackets(c)
    }

    /** Bidik kamera di empat sudut, selang-seling merah/putih seperti ikon. */
    private fun brackets(c: Canvas) {
        val m = 10 * density
        val l = 26 * density
        val w = width.toFloat()
        val h = height.toFloat()
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3 * density
        val red = 0xFFFF1A1F.toInt()
        val white = 0xFFFFFFFF.toInt()
        paint.color = white
        c.drawLine(m, m, m + l, m, paint); c.drawLine(m, m, m, m + l, paint)
        paint.color = red
        c.drawLine(w - m, m, w - m - l, m, paint); c.drawLine(w - m, m, w - m, m + l, paint)
        c.drawLine(m, h - m, m + l, h - m, paint); c.drawLine(m, h - m, m, h - m - l, paint)
        paint.color = white
        c.drawLine(w - m, h - m, w - m - l, h - m, paint); c.drawLine(w - m, h - m, w - m, h - m - l, paint)
    }
}
