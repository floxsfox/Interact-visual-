package app.interactvisual

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.view.View

/** Menggambar perintah gambar dari Python (L, S, C, R, P, T) di atas kamera. */
class OverlayView(context: Context) : View(context) {

    private class Cmd(
        val k: Char,
        val n: FloatArray,
        val color: Int,
        val w: Float,
        val fill: Boolean,
        val text: String?,
    )

    @Volatile
    private var cmds: List<Cmd> = emptyList()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        typeface = Typeface.MONOSPACE
    }
    private val path = Path()
    private val colors = HashMap<String, Int>()
    private val density = resources.displayMetrics.density

    private fun col(s: String): Int = colors.getOrPut(s) {
        try {
            android.graphics.Color.parseColor(s)
        } catch (e: Exception) {
            0xFFFFFFFF.toInt()
        }
    }

    fun clear() {
        cmds = emptyList()
        postInvalidate()
    }

    /** Dipanggil dari thread Python. */
    fun submit(s: String) {
        val list = ArrayList<Cmd>(64)
        for (line in s.split('\n')) {
            if (line.length < 3) continue
            try {
                parse(line)?.let { list.add(it) }
            } catch (e: Exception) {
                // baris rusak dilewati
            }
        }
        cmds = list
        postInvalidateOnAnimation()
    }

    private fun f(a: List<String>, from: Int, count: Int) = FloatArray(count) { a[from + it].toFloat() }

    private fun parse(l: String): Cmd? {
        val k = l[0]
        if (k == 'T') {
            val p = l.split(' ', limit = 6)
            return Cmd('T', f(p, 1, 3), col(p[4]), 0f, false, p.getOrElse(5) { "" })
        }
        val p = l.split(' ')
        return when (k) {
            'L' -> Cmd('L', f(p, 1, 4), col(p[6]), p[5].toFloat(), false, null)
            'S' -> Cmd('S', f(p, 3, p.size - 3), col(p[2]), p[1].toFloat(), false, null)
            'C' -> Cmd('C', f(p, 1, 3), col(p[5]), p[4].toFloat(), p[6] == "1", null)
            'R' -> Cmd('R', f(p, 1, 4), col(p[6]), p[5].toFloat(), p[7] == "1", null)
            'P' -> Cmd('P', f(p, 4, p.size - 4), col(p[2]), p[1].toFloat(), p[3] == "1", null)
            else -> null
        }
    }

    override fun onDraw(c: Canvas) {
        for (m in cmds) {
            paint.color = m.color
            val n = m.n
            when (m.k) {
                'L' -> {
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = m.w
                    c.drawLine(n[0], n[1], n[2], n[3], paint)
                }
                'S' -> {
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = m.w
                    c.drawLines(n, 0, (n.size / 4) * 4, paint)
                }
                'C' -> {
                    paint.style = if (m.fill) Paint.Style.FILL else Paint.Style.STROKE
                    paint.strokeWidth = m.w
                    c.drawCircle(n[0], n[1], n[2], paint)
                }
                'R' -> {
                    paint.style = if (m.fill) Paint.Style.FILL else Paint.Style.STROKE
                    paint.strokeWidth = m.w
                    c.drawRect(n[0], n[1], n[0] + n[2], n[1] + n[3], paint)
                }
                'P' -> if (n.size >= 4) {
                    path.reset()
                    path.moveTo(n[0], n[1])
                    var i = 2
                    while (i + 1 < n.size) {
                        path.lineTo(n[i], n[i + 1])
                        i += 2
                    }
                    path.close()
                    paint.style = if (m.fill) Paint.Style.FILL else Paint.Style.STROKE
                    paint.strokeWidth = m.w
                    c.drawPath(path, paint)
                }
                'T' -> {
                    paint.style = Paint.Style.FILL
                    paint.textSize = n[2]
                    c.drawText(m.text ?: "", n[0], n[1], paint)
                }
            }
        }
        brackets(c)
    }

    /** Bidik kamera di empat sudut, selang-seling merah/putih seperti ikon. */
    private fun brackets(c: Canvas) {
        val m = 10 * density
        val l = 26 * density
        val w = width.toFloat()
        val h = height.toFloat()
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3 * density
        val red = 0xFFFF1A1F.toInt()
        val white = 0xFFFFFFFF.toInt()
        paint.color = white
        c.drawLine(m, m, m + l, m, paint); c.drawLine(m, m, m, m + l, paint)
        paint.color = red
        c.drawLine(w - m, m, w - m - l, m, paint); c.drawLine(w - m, m, w - m, m + l, paint)
        c.drawLine(m, h - m, m + l, h - m, paint); c.drawLine(m, h - m, m, h - m - l, paint)
        paint.color = white
        c.drawLine(w - m, h - m, w - m - l, h - m, paint); c.drawLine(w - m, h - m, w - m, h - m - l, paint)
    }
}
