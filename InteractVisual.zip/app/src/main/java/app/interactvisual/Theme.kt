package app.interactvisual

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object C {
    val bg = Color(0xFF0B0B0D)
    val panel = Color(0xFF141417)
    val line = Color(0xFF2A2A30)
    val text = Color(0xFFEDEBE8)
    val dim = Color(0xFF8D8D96)
    val red = Color(0xFFFF1A1F)
    val cyan = Color(0xFF58D6FF)
    val amber = Color(0xFFFFC857)
}

val Mono = FontFamily.Monospace

@Composable
fun Txt(
    s: String,
    color: Color = C.text,
    size: Int = 14,
    bold: Boolean = false,
    modifier: Modifier = Modifier,
) {
    Text(
        text = s,
        modifier = modifier,
        color = color,
        fontSize = size.sp,
        fontFamily = Mono,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
    )
}

@Composable
fun Btn(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    primary: Boolean = false,
    glass: Boolean = false,
) {
    val shape = RoundedCornerShape(4.dp)
    val bg = when {
        primary -> C.red
        glass -> Color(0xB3000000)
        else -> C.panel
    }
    Box(
        modifier
            .clip(shape)
            .background(bg)
            .border(1.dp, if (primary) C.red else if (glass) Color(0x55FFFFFF) else C.line, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Txt(label, if (primary || glass) Color.White else C.text, 13, true)
    }
}

@Composable
fun Card(content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(6.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(C.panel)
            .border(1.dp, C.line, shape)
            .padding(14.dp),
        content = content,
    )
}
