package app.interactvisual

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File

class Preset(val id: String, val title: String, val desc: String)

class ScriptStore(private val ctx: Context) {
    private val dir = File(ctx.filesDir, "scripts").apply { mkdirs() }

    val presets = listOf(
        Preset("voxel_builder", "voxel builder", "bangun kubus wireframe 3D dengan cubitan tangan"),
        Preset("hand_tracking", "hand tracking", "skeleton tangan stabil, jejak jari, cubit, portal dua tangan"),
    )

    fun presetCode(id: String): String =
        ctx.assets.open("presets/$id.py").bufferedReader().use { it.readText() }

    fun list(): List<String> =
        dir.listFiles { f -> f.extension == "py" }?.map { it.nameWithoutExtension }?.sorted() ?: emptyList()

    fun read(name: String): String = File(dir, "$name.py").readText()

    fun write(name: String, code: String) {
        val n = name.trim().ifEmpty { "skrip" }
        File(dir, "$n.py").writeText(code)
    }

    fun delete(name: String) {
        File(dir, "$name.py").delete()
    }

    fun uniqueName(base: String): String {
        var n = base
        var i = 2
        while (File(dir, "$n.py").exists()) {
            n = base + "_" + i
            i++
        }
        return n
    }

    fun import(uri: Uri): String? {
        return try {
            val cr = ctx.contentResolver
            var name = "skrip"
            cr.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) name = c.getString(i) ?: name
                }
            }
            val code = cr.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: return null
            val base = name.substringBeforeLast('.')
                .filter { it.isLetterOrDigit() || it == '_' || it == '-' }
                .ifEmpty { "skrip" }
            val n = uniqueName(base)
            write(n, code)
            n
        } catch (e: Exception) {
            null
        }
    }
}
