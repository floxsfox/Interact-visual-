package app.interactvisual

import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.view.Choreographer
import com.chaquo.python.Python
import java.util.concurrent.Semaphore
import kotlin.math.max

/**
 * Thread Python yang dipacu vsync: tepat satu frame() per refresh layar, dengan posisi tangan
 * diprediksi ke waktu tampil. Perintah gambar dikirim sebagai buffer biner ke overlay.
 */
class PyEngine(private val tracker: Tracker, private val overlay: OverlayView) {
    @Volatile private var running = false
    private var th: Thread? = null
    private val sem = Semaphore(0)

    private val cb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!running) return
            sem.release()
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    fun start(
        code: String,
        name: String,
        density: Float,
        onLog: (String) -> Unit,
        onFps: (Int) -> Unit,
    ) {
        stop()
        running = true
        sem.drainPermits()
        Handler(Looper.getMainLooper()).post {
            if (running) Choreographer.getInstance().postFrameCallback(cb)
        }
        th = Thread({
            Process.setThreadPriority(Process.THREAD_PRIORITY_DISPLAY)
            try {
                val rt = Python.getInstance().getModule("iv_runtime")
                val err = rt.callAttr("load", code, name).toString()
                if (err.isNotEmpty()) onLog(err + "\n")
                // skrip menentukan butuh 1 atau 2 tangan (1 tangan jauh lebih ringan: tanpa palm detection tiap frame)
                tracker.setHands(rt.callAttr("max_hands").toInt())
                val sb = StringBuilder()
                var prev = System.nanoTime()
                var fpsT = prev
                var frames = 0
                var tick = 0
                while (running) {
                    sem.acquire()
                    sem.drainPermits() // kalau telat, lompat ke vsync terbaru (jangan menumpuk)
                    if (!running) break
                    val t0 = System.nanoTime()
                    val w = overlay.width
                    val h = overlay.height
                    if (w <= 0 || h <= 0) continue

                    // frame ini baru tampil ~2 vsync lagi (digambar di vsync berikutnya, di-scanout setelahnya)
                    val period = (1e9f / (overlay.display?.refreshRate ?: 60f)).toLong()
                    val hf = tracker.sample(SystemClock.elapsedRealtimeNanos() + 2 * period)

                    var n = 0
                    sb.setLength(0)
                    if (hf != null && hf.hands.isNotEmpty()) {
                        // koordinat gambar kamera -> px layar (PreviewView FILL_CENTER)
                        val sc = max(w.toFloat() / hf.imgW, h.toFloat() / hf.imgH)
                        val ox = (w - hf.imgW * sc) / 2f
                        val oy = (h - hf.imgH * sc) / 2f
                        for (a in hf.hands) {
                            n++
                            for (i in 0 until 21) {
                                sb.append(a[i * 3] * hf.imgW * sc + ox).append(' ')
                                sb.append(a[i * 3 + 1] * hf.imgH * sc + oy).append(' ')
                                sb.append(a[i * 3 + 2] * hf.imgW * sc).append(' ')
                            }
                        }
                    }
                    val dt = (t0 - prev) / 1e9f
                    prev = t0
                    val out = rt.callAttr(
                        "frame", w, h, density, n, sb.toString(), dt,
                        if (tracker.front) "front" else "back",
                    ).toJava(ByteArray::class.java)
                    overlay.submit(out)

                    frames++
                    if (t0 - fpsT > 1_000_000_000L) {
                        onFps(frames)
                        frames = 0
                        fpsT = t0
                    }
                    tick++
                    if (tick % 30 == 0) {
                        val l = rt.callAttr("pop_logs").toString()
                        if (l.isNotEmpty()) onLog(l)
                    }
                }
            } catch (e: InterruptedException) {
                // berhenti
            } catch (e: Throwable) {
                onLog("engine: $e\n")
            }
        }, "iv-python").also { it.start() }
    }

    fun stop() {
        running = false
        sem.release()
        Choreographer.getInstance().removeFrameCallback(cb)
        th?.join(800)
        th = null
        overlay.clear()
    }
}
