package app.interactvisual

import com.chaquo.python.Python
import kotlin.math.max

/** Thread Python: ambil hasil tangan terbaru, panggil frame() di iv_runtime, kirim perintah gambar ke overlay. */
class PyEngine(private val tracker: Tracker, private val overlay: OverlayView) {
    @Volatile private var running = false
    private var th: Thread? = null

    fun start(
        code: String,
        name: String,
        density: Float,
        onLog: (String) -> Unit,
        onFps: (Int) -> Unit,
    ) {
        stop()
        running = true
        th = Thread({
            try {
                val rt = Python.getInstance().getModule("iv_runtime")
                val err = rt.callAttr("load", code, name).toString()
                if (err.isNotEmpty()) onLog(err + "\n")
                val sb = StringBuilder()
                var prev = System.nanoTime()
                var fpsT = prev
                var frames = 0
                var tick = 0
                while (running) {
                    val t0 = System.nanoTime()
                    val w = overlay.width
                    val h = overlay.height
                    if (w <= 0 || h <= 0) {
                        Thread.sleep(16)
                        continue
                    }
                    var n = 0
                    sb.setLength(0)
                    val hf = tracker.latest
                    if (hf != null && hf.hands.isNotEmpty()) {
                        // petakan koordinat gambar kamera -> px layar (PreviewView FILL_CENTER)
                        val sc = max(w.toFloat() / hf.imgW, h.toFloat() / hf.imgH)
                        val ox = (w - hf.imgW * sc) / 2f
                        val oy = (h - hf.imgH * sc) / 2f
                        for (a in hf.hands) {
                            n++
                            for (i in 0 until 21) {
                                sb.append(a[i * 3] * hf.imgW * sc + ox).append(' ')
                                sb.append(a[i * 3 + 1] * hf.imgH * sc + oy).append(' ')
                                sb.append(a[i * 3 + 2] * hf.imgW * sc).append(' ')
                            }
                        }
                    }
                    val dt = (t0 - prev) / 1e9f
                    prev = t0
                    val out = rt.callAttr(
                        "frame", w, h, density, n, sb.toString(), dt,
                        if (tracker.front) "front" else "back",
                    ).toString()
                    overlay.submit(out)

                    frames++
                    if (t0 - fpsT > 1_000_000_000L) {
                        onFps(frames)
                        frames = 0
                        fpsT = t0
                    }
                    tick++
                    if (tick % 10 == 0) {
                        val l = rt.callAttr("pop_logs").toString()
                        if (l.isNotEmpty()) onLog(l)
                    }
                    val spent = (System.nanoTime() - t0) / 1_000_000L
                    if (spent < 10) Thread.sleep(10 - spent)
                }
            } catch (e: InterruptedException) {
                // berhenti
            } catch (e: Throwable) {
                onLog("engine: $e\n")
            }
        }, "iv-python").also { it.start() }
    }

    fun stop() {
        running = false
        th?.join(800)
        th = null
        overlay.clear()
    }
}
