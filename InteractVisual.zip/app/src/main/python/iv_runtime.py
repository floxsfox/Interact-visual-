"""Runtime Python untuk Interact Visual. Dipanggil dari Kotlin tiap frame."""
import math
import sys
import time
import traceback


class _Buf:
    def __init__(self):
        self.parts = []

    def write(self, s):
        if s:
            self.parts.append(s)
            return len(s)
        return 0

    def flush(self):
        pass

    def pop(self):
        t = "".join(self.parts)
        self.parts = []
        return t


_buf = _Buf()
sys.stdout = _buf
sys.stderr = _buf

_NAMED = {
    "white": "#FFFFFF", "black": "#000000", "red": "#FF1A1F", "green": "#33FF99",
    "blue": "#3D8BFF", "yellow": "#FFD23F", "pink": "#FF2E88", "cyan": "#2EE6FF",
    "gray": "#8D8D96",
}


def _col(c):
    if isinstance(c, str):
        if c.startswith("#"):
            if len(c) == 4:
                return "#" + "".join(ch * 2 for ch in c[1:])
            return c
        return _NAMED.get(c, "#FFFFFF")
    v = [max(0, min(255, int(x))) for x in c]
    if len(v) >= 4:
        return "#%02X%02X%02X%02X" % (v[3], v[0], v[1], v[2])
    return "#%02X%02X%02X" % (v[0], v[1], v[2])


def dist(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


def clamp(v, lo, hi):
    return lo if v < lo else hi if v > hi else v


def lerp(a, b, t):
    return a + (b - a) * t


class Draw:
    def __init__(self):
        self.out = []

    def line(self, x1, y1, x2, y2, color="#FFFFFF", width=2):
        self.out.append("L %.1f %.1f %.1f %.1f %.1f %s" % (x1, y1, x2, y2, width, _col(color)))

    def segments(self, pts, color="#FFFFFF", width=2):
        if len(pts) >= 4:
            self.out.append("S %.1f %s %s" % (width, _col(color), " ".join(["%.1f" % v for v in pts])))

    def circle(self, x, y, r, color="#FFFFFF", width=2, fill=False):
        self.out.append("C %.1f %.1f %.1f %.1f %s %d" % (x, y, r, width, _col(color), 1 if fill else 0))

    def rect(self, x, y, w, h, color="#FFFFFF", width=2, fill=False):
        self.out.append("R %.1f %.1f %.1f %.1f %.1f %s %d" % (x, y, w, h, width, _col(color), 1 if fill else 0))

    def poly(self, pts, color="#FFFFFF", width=2, fill=False):
        if len(pts) >= 2:
            flat = " ".join(["%.1f %.1f" % (p[0], p[1]) for p in pts])
            self.out.append("P %.1f %s %d %s" % (width, _col(color), 1 if fill else 0, flat))

    def text(self, x, y, s, color="#FFFFFF", size=14):
        s = str(s).replace("\n", " ")
        self.out.append("T %.1f %.1f %.1f %s %s" % (x, y, size, _col(color), s))


_TIPS = (4, 8, 12, 16, 20)


class Hand:
    def __init__(self, pts):
        self.pts = pts  # 21 titik (x, y, z) dalam px layar

    def tip(self, f):
        return self.pts[_TIPS[f]]

    @property
    def size(self):
        return dist(self.pts[0], self.pts[9]) or 1.0

    def pinch(self, f=1):
        return dist(self.pts[4], self.pts[_TIPS[f]]) / self.size

    def fingers(self):
        p = self.pts
        w = p[0]
        up = [dist(p[4], p[17]) > dist(p[3], p[17])]
        for t in (8, 12, 16, 20):
            up.append(dist(p[t], w) > dist(p[t - 2], w))
        return up


class Ctx:
    def __init__(self):
        self.w = 0
        self.h = 0
        self.dp = 1.0
        self.t = 0.0
        self.dt = 0.0
        self.cam = "back"
        self.hands = []


_ctx = Ctx()
_ns = None
_err = None
_setup_done = False
_t0 = time.time()


def load(code, name):
    global _ns, _err, _setup_done, _t0
    _ns, _err, _setup_done, _t0 = None, None, False, time.time()
    _buf.pop()
    ns = {"__name__": "__main__", "dist": dist, "clamp": clamp, "lerp": lerp}
    try:
        exec(compile(code, name + ".py", "exec"), ns)
    except BaseException:
        _err = traceback.format_exc()
        return _err
    if not callable(ns.get("frame")):
        _err = "Skrip harus punya fungsi: def frame(ctx, d)"
        return _err
    _ns = ns
    return ""


def frame(w, h, dp, n, data, dt, cam):
    global _err, _setup_done
    c = _ctx
    c.w, c.h, c.dp, c.dt, c.cam, c.t = w, h, dp, dt, cam, time.time() - _t0
    hs = []
    if n:
        v = [float(x) for x in data.split()]
        for i in range(n):
            o = i * 63
            hs.append(Hand([(v[o + j * 3], v[o + j * 3 + 1], v[o + j * 3 + 2]) for j in range(21)]))
    c.hands = hs
    d = Draw()
    if _ns is not None and _err is None:
        try:
            if not _setup_done:
                _setup_done = True
                if callable(_ns.get("setup")):
                    _ns["setup"](c)
            _ns["frame"](c, d)
        except BaseException:
            _err = traceback.format_exc()
            print(_err)
    if _err:
        d.text(24 * dp, 150 * dp, "error - buka log", "#FF4040", 16 * dp)
    return "\n".join(d.out)


def pop_logs():
    return _buf.pop()
