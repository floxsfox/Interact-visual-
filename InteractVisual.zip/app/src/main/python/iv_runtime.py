"""Runtime Python untuk Interact Visual. Dipanggil dari Kotlin tiap frame."""
import math
import sys
import time
import traceback
from array import array


class _Buf:
    def __init__(self):
        self.parts = []

    def write(self, s):
        if s:
            self.parts.append(s)
            return len(s)
        return 0

    def flush(self):
        pass

    def pop(self):
        t = "".join(self.parts)
        self.parts = []
        return t


_buf = _Buf()
sys.stdout = _buf
sys.stderr = _buf

_NAMED = {
    "white": "#FFFFFF", "black": "#000000", "red": "#FF1A1F", "green": "#33FF99",
    "blue": "#3D8BFF", "yellow": "#FFD23F", "pink": "#FF2E88", "cyan": "#2EE6FF",
    "gray": "#8D8D96",
}


_cc = {}


def _rgba(c):
    if isinstance(c, str):
        r = _cc.get(c)
        if r is not None:
            return r
        h = _NAMED.get(c, c).lstrip("#")
        if len(h) == 3:
            h = "".join(ch * 2 for ch in h)
        try:
            if len(h) == 8:  # #AARRGGBB
                r = (int(h[2:4], 16), int(h[4:6], 16), int(h[6:8], 16), int(h[0:2], 16))
            else:
                r = (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), 255)
        except ValueError:
            r = (255, 255, 255, 255)
        _cc[c] = r
        return r
    v = [max(0, min(255, int(x))) for x in c]
    return (v[0], v[1], v[2], v[3] if len(v) > 3 else 255)


def dist(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


def clamp(v, lo, hi):
    return lo if v < lo else hi if v > hi else v


def lerp(a, b, t):
    return a + (b - a) * t


class Draw:
    """Perintah gambar disimpan sebagai float biner: [tipe, lebar, a, r, g, b, fill, n, payload...].
    tipe: 1 garis/segmen, 2 lingkaran, 3 kotak, 4 poligon, 5 teks."""

    def __init__(self):
        self.a = array("f")

    def _h(self, t, width, color, fill, n):
        r, g, b, a = _rgba(color)
        self.a.extend((t, width, a, r, g, b, 1.0 if fill else 0.0, n))

    def line(self, x1, y1, x2, y2, color="#FFFFFF", width=2):
        self._h(1, width, color, False, 4)
        self.a.extend((x1, y1, x2, y2))

    def segments(self, pts, color="#FFFFFF", width=2):
        n = len(pts) // 4 * 4
        if n:
            self._h(1, width, color, False, n)
            self.a.extend(pts if n == len(pts) else pts[:n])

    def circle(self, x, y, r, color="#FFFFFF", width=2, fill=False):
        self._h(2, width, color, fill, 3)
        self.a.extend((x, y, r))

    def rect(self, x, y, w, h, color="#FFFFFF", width=2, fill=False):
        self._h(3, width, color, fill, 4)
        self.a.extend((x, y, w, h))

    def poly(self, pts, color="#FFFFFF", width=2, fill=False):
        if len(pts) >= 2:
            self._h(4, width, color, fill, len(pts) * 2)
            self.a.extend([v for p in pts for v in (p[0], p[1])])

    def text(self, x, y, s, color="#FFFFFF", size=14):
        s = str(s)
        self._h(5, 0, color, False, 3 + len(s))
        self.a.extend((x, y, size))
        self.a.extend([float(o if (o := ord(ch)) < 65536 else 63) for ch in s])


_TIPS = (4, 8, 12, 16, 20)


class Hand:
    def __init__(self, pts):
        self.pts = pts  # 21 titik (x, y, z) dalam px layar

    def tip(self, f):
        return self.pts[_TIPS[f]]

    @property
    def size(self):
        return dist(self.pts[0], self.pts[9]) or 1.0

    def pinch(self, f=1):
        return dist(self.pts[4], self.pts[_TIPS[f]]) / self.size

    def fingers(self):
        p = self.pts
        w = p[0]
        up = [dist(p[4], p[17]) > dist(p[3], p[17])]
        for t in (8, 12, 16, 20):
            up.append(dist(p[t], w) > dist(p[t - 2], w))
        return up


class Ctx:
    def __init__(self):
        self.w = 0
        self.h = 0
        self.dp = 1.0
        self.t = 0.0
        self.dt = 0.0
        self.cam = "back"
        self.top = 0.0  # batas bawah HUD aplikasi (px), taruh teks status di bawah y ini
        self.hands = []


_ctx = Ctx()
_ns = None
_err = None
_setup_done = False
_t0 = time.time()


def load(code, name):
    global _ns, _err, _setup_done, _t0
    _ns, _err, _setup_done, _t0 = None, None, False, time.time()
    _buf.pop()
    ns = {"__name__": "__main__", "dist": dist, "clamp": clamp, "lerp": lerp}
    try:
        exec(compile(code, name + ".py", "exec"), ns)
    except BaseException:
        _err = traceback.format_exc()
        return _err
    if not callable(ns.get("frame")):
        _err = "Skrip harus punya fungsi: def frame(ctx, d)"
        return _err
    _ns = ns
    return ""


def frame(w, h, dp, n, data, dt, cam):
    global _err, _setup_done
    c = _ctx
    c.w, c.h, c.dp, c.dt, c.cam, c.t = w, h, dp, dt, cam, time.time() - _t0
    c.top = 140 * dp
    hs = []
    if n:
        v = [float(x) for x in data.split()]
        for i in range(n):
            o = i * 63
            hs.append(Hand([(v[o + j * 3], v[o + j * 3 + 1], v[o + j * 3 + 2]) for j in range(21)]))
    c.hands = hs
    d = Draw()
    if _ns is not None and _err is None:
        try:
            if not _setup_done:
                _setup_done = True
                if callable(_ns.get("setup")):
                    _ns["setup"](c)
            _ns["frame"](c, d)
        except BaseException:
            _err = traceback.format_exc()
            print(_err)
    if _err:
        d.text(24 * dp, 150 * dp, "error - buka log", "#FF4040", 16 * dp)
    return d.a.tobytes()


def max_hands():
    try:
        return max(1, min(2, int(_ns.get("MAX_HANDS", 1)))) if _ns else 1
    except Exception:
        return 1


def pop_logs():
    return _buf.pop()
