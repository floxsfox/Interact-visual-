# Voxel Builder - bangun kubus 3D pakai tangan
#   cubit jempol+telunjuk : pasang kubus      cubit jempol+tengah : hapus
#   2 tangan : tangan kiri memutar pandangan  kepalan 1 detik : reset
# Dekat/jauh tangan ke kamera = maju/mundur kedalaman kursor.
import math

H = 4                 # grid dari -H sampai H
DEPTH_REF = 0.17      # ukuran telapak (relatif layar) yang dianggap kedalaman 0
DEPTH_GAIN = 60.0     # makin besar = kedalaman makin sensitif
PINK = "#FF2E88"

cubes = set()
yaw = tyaw = 0.6
pitch = tpitch = 0.5
depth = 0.0
fist_t = 0.0
pin = {}
geo = ([], [])
dirty = True
S = 40.0
cyw = syw = cpt = spt = 1.0


def setup(ctx):
    cubes.update({(0, -H, 0), (1, -H, 0), (0, -H, 1)})


def edge(name, val):
    was = pin.get(name, False)
    now = val < (0.46 if was else 0.30)
    pin[name] = now
    return now and not was


def project(x, y, z, ctx):
    x1 = x * cyw + z * syw
    z1 = -x * syw + z * cyw
    y1 = y * cpt - z1 * spt
    return ctx.w / 2 + x1 * S, ctx.h / 2 - y1 * S


def unproject(px, py, dz, ctx):
    u = (px - ctx.w / 2) / S
    v = -(py - ctx.h / 2) / S
    y = v * cpt + dz * spt
    z1 = -v * spt + dz * cpt
    return u * cyw - z1 * syw, y, u * syw + z1 * cyw


def build():
    verts, edges = {}, set()
    for (cx, cy, cz) in cubes:
        ids = []
        for dx in (-1, 1):
            for dy in (-1, 1):
                for dz in (-1, 1):
                    v = (2 * cx + dx, 2 * cy + dy, 2 * cz + dz)
                    if v not in verts:
                        verts[v] = len(verts)
                    ids.append(verts[v])
        for a in range(8):
            for bit in (1, 2, 4):
                if not a & bit:
                    p, q = ids[a], ids[a | bit]
                    edges.add((p, q) if p < q else (q, p))
    return list(verts.keys()), list(edges)


def cube_segs(c, ctx):
    pts = []
    for i in range(8):
        pts.append(project(c[0] + (0.5 if i & 4 else -0.5),
                           c[1] + (0.5 if i & 2 else -0.5),
                           c[2] + (0.5 if i & 1 else -0.5), ctx))
    segs = []
    for a in range(8):
        for bit in (1, 2, 4):
            if not a & bit:
                segs += (pts[a][0], pts[a][1], pts[a | bit][0], pts[a | bit][1])
    return segs


def frame(ctx, d):
    global yaw, pitch, tyaw, tpitch, depth, fist_t, geo, dirty, S, cyw, syw, cpt, spt
    dp = ctx.dp
    hands = ctx.hands
    S = min(ctx.w, ctx.h) / (2 * H + 3.0)

    if len(hands) == 2:  # tangan kiri layar = putar
        p = hands[0].pts[9]
        tyaw = (p[0] / ctx.w - 0.5) * 5.0
        tpitch = clamp((0.5 - p[1] / ctx.h) * 3.0, -1.2, 1.2)
    yaw += (tyaw - yaw) * 0.25
    pitch += (tpitch - pitch) * 0.25
    cyw, syw, cpt, spt = math.cos(yaw), math.sin(yaw), math.cos(pitch), math.sin(pitch)

    # lantai
    lo, hi = -H - 0.5, H + 0.5
    g = []
    for i in range(-H, H + 2):
        t = i - 0.5
        a, b = project(t, lo, lo, ctx), project(t, lo, hi, ctx)
        g += (a[0], a[1], b[0], b[1])
        a, b = project(lo, lo, t, ctx), project(hi, lo, t, ctx)
        g += (a[0], a[1], b[0], b[1])
    d.segments(g, (255, 255, 255, 50), 1 * dp)

    # kubus (cache geometri, hanya dibangun ulang kalau berubah)
    if dirty:
        geo = build()
        dirty = False
    verts, edges = geo
    pv = [project(v[0] / 2.0, v[1] / 2.0, v[2] / 2.0, ctx) for v in verts]
    segs = []
    for a, b in edges:
        segs += (pv[a][0], pv[a][1], pv[b][0], pv[b][1])
    d.segments(segs, PINK, 2.2 * dp)

    if hands:
        hd = hands[-1]  # tangan kanan layar = membangun
        fx, fy, _z = hd.tip(1)
        target = (hd.size / min(ctx.w, ctx.h) - DEPTH_REF) * DEPTH_GAIN
        depth += (clamp(target, -H, H) - depth) * 0.2
        wx, wy, wz = unproject(fx, fy, depth, ctx)
        cell = tuple(int(clamp(round(c), -H, H)) for c in (wx, wy, wz))

        d.segments(cube_segs(cell, ctx), "#FF1A1F" if cell in cubes else "#FFFFFF", 2.5 * dp)
        d.circle(fx, fy, 7 * dp, "#FF1A1F", 1, True)

        pi, pm = hd.pinch(1), hd.pinch(2)
        if edge("put", pi if pi < pm else 9.0):
            cubes.add(cell)
            dirty = True
        if edge("del", pm if pm < pi else 9.0):
            cubes.discard(cell)
            dirty = True

        if not any(hd.fingers()):  # kepalan = reset
            fist_t += ctx.dt
            d.text(24 * dp, 120 * dp, "tahan kepalan %.1f / 1.0" % fist_t, "#FF1A1F", 13 * dp)
            if fist_t > 1.0:
                cubes.clear()
                dirty = True
                fist_t = 0.0
        else:
            fist_t = 0.0

    d.text(24 * dp, 96 * dp, "voxel builder  %d kubus" % len(cubes), "#FFFFFF", 14 * dp)
    y0 = ctx.h - 84 * dp
    for i, s in enumerate(("cubit jempol+telunjuk = pasang",
                           "cubit jempol+tengah = hapus",
                           "2 tangan: kiri putar | kepalan = reset")):
        d.text(24 * dp, y0 + i * 20 * dp, s, (255, 255, 255, 190), 11 * dp)
