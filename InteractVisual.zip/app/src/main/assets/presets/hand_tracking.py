# Hand Tracking - skeleton stabil, jejak jari, deteksi cubit, portal dua tangan
BONES = [(0, 1), (1, 2), (2, 3), (3, 4), (0, 5), (5, 6), (6, 7), (7, 8), (5, 9), (9, 10),
         (10, 11), (11, 12), (9, 13), (13, 14), (14, 15), (15, 16), (13, 17), (17, 18),
         (18, 19), (19, 20), (0, 17)]
TIPS = (4, 8, 12, 16, 20)
RED = "#FF2A2A"

trails = {0: [], 1: []}
pinched = {}


def pinch_edge(i, r):
    on = pinched.get(i, False)
    on = r < (0.45 if on else 0.30)  # histeresis: biar tidak berkedip
    pinched[i] = on
    return on


def frame(ctx, d):
    dp = ctx.dp
    hands = ctx.hands
    d.text(24 * dp, 96 * dp, "hand tracking  %d tangan" % len(hands), "#FFFFFF", 14 * dp)

    for i, hand in enumerate(hands):
        p = hand.pts
        segs = []
        for a, b in BONES:
            segs += (p[a][0], p[a][1], p[b][0], p[b][1])
        d.segments(segs, "#CCFFFFFF", 2.5 * dp)
        for k, q in enumerate(p):
            tip = k in TIPS
            d.circle(q[0], q[1], (6 if tip else 3.5) * dp, RED if tip else "#FFFFFF", 1, True)

        # jejak ujung telunjuk
        t = trails[i]
        t.append((p[8][0], p[8][1]))
        if len(t) > 22:
            t.pop(0)
        for k in range(1, len(t)):
            f = k / len(t)
            d.line(t[k - 1][0], t[k - 1][1], t[k][0], t[k][1], (255, 42, 42, int(255 * f)), (1 + 5 * f) * dp)

        # cubit jempol-telunjuk
        r = hand.pinch(1)
        on = pinch_edge(i, r)
        mx, my = (p[4][0] + p[8][0]) / 2, (p[4][1] + p[8][1]) / 2
        d.circle(mx, my, hand.size * 0.32, RED, 3 * dp, on)

        n = sum(hand.fingers())
        d.text(p[0][0] - 40 * dp, p[0][1] + 44 * dp, "%d jari  cubit %.2f" % (n, r), "#FFFFFF", 12 * dp)

    for i in range(len(hands), 2):
        trails[i] = []

    # portal: bingkai dari jempol + telunjuk dua tangan
    if len(hands) == 2:
        a, b = hands[0].pts, hands[1].pts
        quad = [a[4], a[8], b[8], b[4]]
        d.poly(quad, (255, 42, 42, 70), 3 * dp, True)
        d.poly(quad, "#FFFFFF", 2 * dp, False)
        for k in range(1, 8):
            f = k / 8.0
            x1 = a[4][0] + (a[8][0] - a[4][0]) * f
            y1 = a[4][1] + (a[8][1] - a[4][1]) * f
            x2 = b[4][0] + (b[8][0] - b[4][0]) * f
            y2 = b[4][1] + (b[8][1] - b[4][1]) * f
            d.line(x1, y1, x2, y2, (255, 255, 255, 60), 1 * dp)
        cx = sum(q[0] for q in quad) / 4
        cy = sum(q[1] for q in quad) / 4
        d.text(cx - 30 * dp, cy, "portal", "#FFFFFF", 14 * dp)
