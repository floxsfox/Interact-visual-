# Interact Visual

Kode Python interaktif di atas kamera ponsel (Kotlin + Chaquopy + CameraX + MediaPipe).

## Cara kerja
- Kotlin: kamera (depan/belakang, rotasi bebas), deteksi tangan MediaPipe, penghalusan One-Euro, menggambar overlay.
- Python: skrip kamu (`def frame(ctx, d)`), dipanggil tiap frame. Python hanya mengurus logika dan perintah gambar,
  jadi tetap lancar.
- Preset: `voxel builder` dan `hand tracking` (lihat `app/src/main/assets/presets/`).
- Referensi API ada di dalam aplikasi (tombol "referensi API") dan di `app/src/main/assets/docs.txt`.

## Build lewat GitHub (dari ponsel)
1. Upload `InteractVisual.zip` ke root repo.
2. Buat file `.github/workflows/build-apk.yml`, isi dengan `build-apk.yml` yang menyertai ZIP ini.
3. Tab Actions, pilih "Build Interact Visual APK", Run workflow.
4. Unduh APK dari Artifacts (`InteractVisual-Debug-APK`).

Workflow mengunduh model `hand_landmarker.task` (MediaPipe) otomatis saat build.

## Catatan
- APK hanya arm64-v8a (hampir semua ponsel modern). Tambah ABI di `app/build.gradle.kts` kalau perlu.
- Python di aplikasi hanya pustaka standar (numpy/opencv belum dipasang).
